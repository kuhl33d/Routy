const Parent = () => {
  return (
    <div>
      <h1>Parent Dashboard</h1>
      <p>Manage your child rides and view ride history.</p>
    </div>
  );
};

export default Parent;
