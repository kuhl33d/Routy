import React from "react";

const School = () => {
  return (
    <div>
      <h1>School Page</h1>
      <p>Welcome to the School page!</p>
    </div>
  );
};

export default School;
