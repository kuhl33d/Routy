const Home = () => {
  console.log("Hello Mon3em");
  return (
    <div>
      <h1>Welcome to KinderRide</h1>
      <h2>Hello Mon3em</h2>
      <p>Your reliable ride-sharing service for kids.</p>
    </div>
  );
};

export default Home;
