import { Routes, Route } from "react-router-dom";
import Home from "./pages/Home/Home";
import Parent from "./pages/Parent/Parent";

function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/parent" element={<Parent />} />
    </Routes>
  );
}

export default App;
